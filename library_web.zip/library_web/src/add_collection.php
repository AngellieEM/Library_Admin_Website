<?php
include "connection.php";

if (isset($_POST['bcsave'])) {
    $title = $_POST['ctitle'];
    $author = $_POST['cauthor'];
    $publisher = $_POST['cpublisher'];
    $year = $_POST['cyear'];
    $category_name = $_POST['ccategory']; 
    $stock = $_POST['cstock'];

    $sql_category = "SELECT id_category FROM category WHERE category_name = '$category_name'";
    $result_category = $conn->query($sql_category);

    if ($result_category->num_rows > 0) {
        $row = $result_category->fetch_assoc();
        $id_category = $row['id_category']; 

        $sql_collection = "INSERT INTO collection (collection_title, collection_author, collection_publisher, collection_year, id_category, collection_stock)
                            VALUES ('$title', '$author', '$publisher', '$year', '$id_category', '$stock')";

        if ($conn->query($sql_collection) === TRUE) {
            echo "
            <script>
                alert('Successfully saved the collection data!');
                document.location.href = 'index.php';
            </script>
            ";
        } else {
            echo "
            <script>
                alert('Failed to save collection data!');
                document.location.href = 'index.php';
            </script>
            ";
        }
    } else {
        echo "
        <script>
            alert('Invalid category name! Please check the category.');
            document.location.href = 'index.php';
        </script>
        ";
    }
}
?>
