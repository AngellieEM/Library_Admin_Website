<?php
$servername = "localhost";
$username = "root";  // Default username untuk XAMPP/WAMP
$password = "";      // Default password untuk XAMPP/WAMP
$dbname = "db_library"; // Ganti dengan nama database kamu

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

function query($query) { // Nama fungsi diubah menjadi query
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = []; // Inisialisasi array kosong
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

// Mengecek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
