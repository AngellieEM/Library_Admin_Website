<?php
include "connection.php";

if (isset($_POST['bmedit'])) {
    $edit = mysqli_query($conn, "UPDATE member SET 
                                    member_name         = '$_POST[mname]',
                                    member_address      = '$_POST[maddress]',
                                    member_phone_number = '$_POST[mpnumber]',
                                    member_email        = '$_POST[memail]'
                                WHERE id_member         = '$_POST[id_member]'
                                ");
    if ($edit) {
        echo "
        <script>
            alert('Successfully saved the member data!');
            document.location.href = 'index.php';
        </script>
        ";
    } else {
        echo "
        <script>
            alert('Failed to save member data! Error: " . mysqli_error($conn) . "');
            document.location.href = 'index.php';
        </script>
        ";
    }
}
?>
