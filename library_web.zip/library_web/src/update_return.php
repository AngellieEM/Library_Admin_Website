<?php
include "connection.php"; // Pastikan koneksi database sudah ada

if (isset($_POST['borrowing_id'])) {
    $borrowing_id = $_POST['borrowing_id'];
    $return_date = date('Y-m-d'); // Tanggal hari ini

    // Update status dan tanggal pengembalian di tabel return_collection
    $sql = "UPDATE return_collection 
            SET return_date = '$return_date', status = 'returned' 
            WHERE id_borrowing_collection = $borrowing_id";

    if ($conn->query($sql) === TRUE) {
        // Jika update berhasil, lakukan apa yang diperlukan
        echo "Success";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
