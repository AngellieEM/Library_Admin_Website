<?php
include "connection.php";

if (isset($_POST['bdelete'])) {
    $id_collection = $_POST['id_collection'];

    $sql_delete = "DELETE FROM collection WHERE id_collection = '$id_collection'";

    if ($conn->query($sql_delete) === TRUE) {
        echo "
        <script>
            alert('Successfully deleted the collection data!');
            document.location.href = 'index.php';
        </script>
        ";
    } else {
        echo "
        <script>
            alert('Failed to delete collection data! Error: " . $conn->error . "');
            document.location.href = 'index.php';
        </script>
        ";
    }
}
?>
