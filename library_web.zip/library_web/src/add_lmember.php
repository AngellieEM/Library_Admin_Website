<?php
include "connection.php";

if (isset($_POST['bmsave'])) {
    $name = $_POST['mname'];
    $address = $_POST['maddress'];
    $phone_number = $_POST['mpnumber'];
    $email = $_POST['memail'];

    
    $sql_member = "INSERT INTO member (member_name, member_address, member_phone_number, member_email)
    VALUES ('$name', '$address', '$phone_number', '$email')";

    if ($conn->query($sql_member) === TRUE) {
        echo "
        <script>
            alert('Successfully saved the member data!');
            document.location.href = 'index.php';
        </script>
        ";
    } else {
        echo "
        <script>
            alert('Failed to save member data!');
            document.location.href = 'index.php';
        </script>
        ";
    }
} 
?>
