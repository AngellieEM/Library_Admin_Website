<?php
include "connection.php";
$book_collection = query("SELECT 
	c.id_collection, c.collection_title, c.collection_author, c.collection_publisher, c.collection_year, cat.category_name, c.collection_stock 
FROM collection c
LEFT JOIN category cat ON c.id_category = cat.id_category;");

$select_category = query("SELECT id_category, category_name from category 
order by category_name ASC;");

$librarian_member = query("SELECT * FROM member");

$borrowing_list = query("SELECT m.member_name,
               c.collection_title,
               b.borrow_date,
               b.due_date
              FROM borrowing_collection b
              JOIN member m ON b.id_member = m.id_member
              JOIN collection c ON b.id_collection = c.id_collection
              ORDER BY b.borrow_date DESC");

$return_list = query("SELECT r.id_return_collection, r.id_borrowing_collection, r.return_date, r.status,
                              b.borrow_date, b.due_date, m.member_name, c.collection_title
                       FROM return_collection r
                       JOIN borrowing_collection b ON r.id_borrowing_collection = b.id_borrowing_collection
                       JOIN member m ON b.id_member = m.id_member
                       JOIN collection c ON b.id_collection = c.id_collection
                       ORDER BY r.return_date DESC");

// Query untuk menghitung jumlah peminjaman hari ini
$sql_today_borrowings = "SELECT COUNT(*) as count_today FROM borrowing_collection WHERE DATE(borrow_date) = CURDATE()";
$result_today_borrowings = $conn->query($sql_today_borrowings);
$row_today = $result_today_borrowings->fetch_assoc();
$count_today = $row_today['count_today'];

// Query untuk menghitung total peminjaman dalam 30 hari terakhir
$sql_last_30_days = "SELECT COUNT(*) as count_last_30_days FROM borrowing_collection WHERE borrow_date >= CURDATE() - INTERVAL 30 DAY";
$result_last_30_days = $conn->query($sql_last_30_days);
$row_last_30_days = $result_last_30_days->fetch_assoc();
$count_last_30_days = $row_last_30_days['count_last_30_days'];

// Menghitung persentase
$percentage = 0;
if ($count_last_30_days > 0) {
    $percentage = ($count_today / $count_last_30_days) * 100;
}

// Query untuk menghitung total peminjaman (total borrowings)
$sql_total_borrowings = "SELECT COUNT(*) as count_total FROM borrowing_collection";
$result_total_borrowings = $conn->query($sql_total_borrowings);
$row_total = $result_total_borrowings->fetch_assoc();
$count_total = $row_total['count_total'];

// Query untuk menghitung jumlah peminjaman dalam 30 hari terakhir
$sql_last_30_days = "SELECT COUNT(*) as count_last_30_days FROM borrowing_collection WHERE borrow_date >= CURDATE() - INTERVAL 30 DAY";
$result_last_30_days = $conn->query($sql_last_30_days);
$row_last_30_days = $result_last_30_days->fetch_assoc();
$count_last_30_days = $row_last_30_days['count_last_30_days'];

// Menghitung persentase
$percentage = 0;
if ($count_total > 0) {
    $percentage = ($count_last_30_days / $count_total) * 100;
}

// Query untuk menghitung total stok koleksi
$sql_total_collections = "SELECT SUM(collection_stock) AS total_collection_stock FROM collection";
$result_total_collections = $conn->query($sql_total_collections);
if ($result_total_collections) {
    $row_total_collections = $result_total_collections->fetch_assoc();
    $count_total_collections = $row_total_collections['total_collection_stock']; // Ambil hasil penjumlahan stok
} else {
    $count_total_collections = 0; // Jika query gagal, set nilai default
}
echo $count_total_collections;

// Query untuk menghitung total `id_member`
$sql_total_members = "SELECT COUNT(id_member) AS total_members FROM member";

// Menjalankan query dan menangani kesalahan jika terjadi
$result = $conn->query($sql_total_members);

// Ambil hasil query
$row = $result->fetch_assoc();
$total_members = $row['total_members'];

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>InfiniReads</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/vendors/feather/feather.css">
    <link rel="stylesheet" href="assets/vendors/ti-icons/css/themify-icons.css">
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css">
    <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- <link rel="stylesheet" href="assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css"> -->
    <link rel="stylesheet" href="assets/vendors/datatables.net-bs5/dataTables.bootstrap5.css">
    <link rel="stylesheet" href="assets/vendors/ti-icons/css/themify-icons.css">
    <link rel="stylesheet" type="text/css" href="assets/js/select.dataTables.min.css">
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="assets/images/favicon.png" />
  </head>
  <!-- FULL SCREEN -->
  <body style="display: flex; flex-direction: column; height: 100%; margin: 0;">
      <!-- partial:partials/_navbar.html -->
      <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
  <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">
    <a class="navbar-brand brand-logo me-5"><img src="assets/images/library-horizontal-logo.png" class="me-2" alt="logo" /></a>
    <!-- href="index.html" inside class -->
    <a class="navbar-brand brand-logo-mini"><img src="assets/images/library-vertical-logo.png" alt="logo" /></a>
  </div>
  <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
    <ul class="navbar-nav navbar-nav-right">
      <li class="nav-item nav-profile dropdown">
        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
          <img src="assets/images/faces/Me.jpg" alt="profile" />
        </a>
        <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
          <a class="dropdown-item">
            <i class="ti-power-off text-primary"></i> Logout </a>
        </div>
      </li>
    </ul>
  </div>
</nav>
      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- FULL SCREEN -->
        <div class="main-panel" style="flex-grow: 1; min-height: 100vh;"> 
          <div class="content-wrapper">
            <div class="row">
              <div class="col-md-12 grid-margin">
                <div class="row">
                  <div class="col-12 col-xl-8 mb-4 mb-xl-0">
                    <h3 class="font-weight-bold">Welcome Angie</h3>
                    <h6 class="font-weight-normal mb-0">All systems are running smoothly!</h6>
                  </div>
                  <div class="col-12 col-xl-4">
                    <div class="justify-content-end d-flex">
                      <div class="dropdown flex-md-grow-1 flex-xl-grow-0">
                        <button class="btn btn-sm btn-light bg-white dropdown-toggle" type="button" id="dropdownMenuDate2" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                          <i class="mdi mdi-menu"></i> Menu </button>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuDate2">
                          <a class="dropdown-item" href="#">Collections</a>
                          <a class="dropdown-item" href="#">Librarian Members</a>
                          <a class="dropdown-item" href="#">History activity</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 grid-margin stretch-card">
                <div class="card tale-bg">
                  <div class="card-people mt-auto">
                    <img src="assets/images/dashboard/people.svg" alt="people">
                    <div class="weather-info">
                      <div class="d-flex">
                        <div>
                          <h2 class="mb-0 font-weight-normal"><i class="icon-sun me-2"></i>30<sup>C</sup></h2>
                        </div>
                        <div class="ms-2">
                          <h4 class="location font-weight-normal">Surabaya</h4>
                          <h6 class="font-weight-normal">Wiyung</h6>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6 grid-margin transparent">
                <div class="row">
                  <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-tale">
                      <div class="card-body">
                        <div class="card-body">
                          <p class="mb-4">Today’s Borrowings</p>
                           <p class="fs-30 mb-2"><?= $count_today; ?></p> <!-- Menampilkan jumlah peminjaman hari ini -->
                          <p><?= number_format($percentage, 2); ?>% (30 days)</p> <!-- Menampilkan persentase peminjaman hari ini dari total 30 hari terakhir -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6 mb-4 stretch-card transparent">
                    <div class="card card-dark-blue">
                      <div class="card-body">
                        <p class="mb-4">Total Borrowings</p>
                        <p class="fs-30 mb-2"><?= $count_total; ?></p> <!-- Menampilkan jumlah total peminjaman -->
                        <p><?= number_format($percentage, 2); ?>% (30 days)</p> <!-- Menampilkan persentase peminjaman dalam 30 hari terakhir dari total peminjaman -->
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-6 mb-4 mb-lg-0 stretch-card transparent">
                    <div class="card card-light-blue">
                      <div class="card-body">
                        <div class="card-body">
                          <p class="mb-4">Number of Collections</p>
                          <p class="fs-30 mb-2"><?= $count_total_collections; ?></p> <!-- Menampilkan jumlah total koleksi -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6 stretch-card transparent">
                    <div class="card card-light-danger">
                      <div class="card-body">
                          <p class="mb-4">Number of Members</p>
                          <p class="fs-30 mb-2"><?= $total_members; ?></p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- COLLECTIONS -->

              <div class="content-wrapper">
                <div class="row">
                  <!-- <div class="col-lg-6 grid-margin stretch-card"> -->
                    <div class="card">
                      <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                          <!-- <h1 class="card-title">Collection</h1> -->
                          <h3 class="font-weight-bold">Collection</h3>
                          <!-- Button trigger modal -->
                          <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#modaladdcollection">
                            Add
                          </button>

                          <!-- Modal add collection -->
                          <div class="modal fade" id="modaladdcollection" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="staticBackdropLabel">Add collection data</h5>
                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                  <form method="POST" action="add_collection.php">
                                    <div class="mb-3">
                                      <label class="form-label">Title</label>
                                      <input type="text" class="form-control" name="ctitle" placeholder="Collection title"required>
                                    </div>
                                    <div class="mb-3">
                                      <label class="form-label">Author</label>
                                      <input type="text" class="form-control" name="cauthor" placeholder="Collection author">
                                    </div>
                                    <div class="mb-3">
                                      <label class="form-label">Publisher</label>
                                      <input type="text" class="form-control" name="cpublisher" placeholder="Collection publisher">
                                    </div>
                                    <div class="mb-3">
                                      <label class="form-label">Year</label>
                                      <input type="text" class="form-control" name="cyear" placeholder="Collection year">
                                    </div>
                                    <div class="mb-3">
                                      <label class="form-label">Category</label>
                                        <div class="input-group mb-3">
                                          <select name="ccategory" class="form-select" id="select_category" required>
                                            <option value="" selected hidden>Select category</option>
                                            <?php
                                              foreach ($select_category as $row) {
                                                echo '<option value="' . $row["category_name"] . '">' . $row["category_name"] . '</option>';
                                              }
                                            ?>
                                          </select>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                      <label class="form-label">Stock</label>
                                      <input type="text" class="form-control" name="cstock" placeholder="Collection stock" required>
                                    </div>
                                    <div class="modal-footer">
                                      <button type="submit" class="btn btn-success" name="bcsave">Save</button>
                                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                            <!-- Last modal add collection -->
                          </div>
                        </div>
                        <p class="card-description"> You can update the collections here!</p>
                        <!-- <button type="button" class="btn btn-info">Add Collection</button> -->
                        <div class="table-responsive" style="max-height: 300px;">
                          <table class="table">
                            <thead>
                              <tr>
                                <th>No.</th>
                                <th>Title</th>
                                <th>Author</th>
                                <th>Publisher</th>
                                <th>Year</th>
                                <th>Category</th>
                                <th>Stock</th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $id=1;?>
                              <?php foreach ($book_collection as $row): ?>
                              <tr>
                                <td><?= $id;?></td>
                                <td><?= $row["collection_title"]?></td>
                                <td><?= $row["collection_author"]?></td>
                                <td><?= $row["collection_publisher"]?></td>
                                <td><?= $row["collection_year"]?></td>
                                <td><?= $row["category_name"]?></td>
                                <td><?= $row["collection_stock"]?></td>
                                <td>
                                  <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modaleditcollection<?=$id;?>">Edit</button>
                                  <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modaldeletecollection<?=$id;?>">Delete</button>                
                                </td>
                              </tr>

                              <!-- Modal edit collection -->
                              <div class="modal fade" id="modaleditcollection<?=$id;?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="staticBackdropLabel">Edit collection data</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                      <form method="POST" action="edit_collection.php">
                                        <input type="hidden" name="id_collection" value="<?=$row['id_collection'];?>">
                                        <div class="mb-3">
                                            <label class="form-label">Title</label>
                                            <input type="text" class="form-control" name="ctitle" value="<?=$row['collection_title'];?>" placeholder="Collection title" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Author</label>
                                            <input type="text" class="form-control" name="cauthor" value="<?=$row['collection_author'];?>" placeholder="Collection author">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Publisher</label>
                                            <input type="text" class="form-control" name="cpublisher" value="<?=$row['collection_publisher'];?>" placeholder="Collection publisher">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Year</label>
                                            <input type="text" class="form-control" name="cyear" value="<?=$row['collection_year'];?>" placeholder="Collection year">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Category</label>
                                            <select name="ccategory" class="form-select" required>
                                                <option value="" disabled>Select category</option>
                                                <?php
                                                foreach ($select_category as $category) {
                                                  $selected = ($category['id_category'] == $row['id_category']) ? 'selected' : '';
                                                  echo "<option value='{$category['id_category']}' $selected>{$category['category_name']}</option>";
                                              }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Stock</label>
                                            <input type="text" class="form-control" name="cstock" value="<?=$row['collection_stock'];?>" placeholder="Collection stock" required>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-success" name="bedit">Save</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                                <!-- Last modal edit collection -->
                              </div>

                              <!-- Modal delete collection -->
                              <div class="modal fade" id="modaldeletecollection<?=$id;?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="staticBackdropLabel">Delete collection data</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                      <form method="POST" action="delete_collection.php">
                                        <input type="hidden" name="id_collection" value="<?=$row['id_collection'];?>">
                                        <div class="mb-3">
                                            <label class="form-label">Are you sure delete the collection data </label>
                                            <label class="form-label">entitled <b><?=$row['collection_title'];?></b>???</label>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary bg-danger" name="bdelete">Delete</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                                <!-- Last modal delete collection -->
                              </div>
                              <?php $id++ ?>
                              <?php endforeach; ?> <!-- Closing 'foreach' is missing -->
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  <!-- </div> -->
                </div>
              </div>

              <!-- LIBRARIAN MEMBERS -->

              <div class="content-wrapper">
                <div class="row">
                  <!-- <div class="col-lg-6 grid-margin stretch-card"> -->
                    <div class="card">
                      <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                          <!-- <h1 class="card-title">Collection</h1> -->
                          <h3 class="font-weight-bold">Librarian Members</h3>
                          <!-- Button trigger modal -->
                          <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#modaladdmember">
                            Add
                          </button>

                          <!-- Modal add member -->
                          <div class="modal fade" id="modaladdmember" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="staticBackdropLabel">Add librarian member data</h5>
                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                  <form method="POST" action="add_lmember.php">
                                    <div class="mb-3">
                                      <label class="form-label">Full Name</label>
                                      <input type="text" class="form-control" name="mname" placeholder="Member full name"required>
                                    </div>
                                    <div class="mb-3">
                                      <label class="form-label">Address</label>
                                      <input type="text" class="form-control" name="maddress" placeholder="Member address">
                                    </div>
                                    <div class="mb-3">
                                      <label class="form-label">Phone Number</label>
                                      <input type="text" class="form-control" name="mpnumber" placeholder="Member address">
                                    </div>
                                    <div class="mb-3">
                                      <label class="form-label">E-mail</label>
                                      <input type="text" class="form-control" name="memail" placeholder="Member E-mail">
                                    </div>
                                    <div class="modal-footer">
                                      <button type="submit" class="btn btn-success" name="bmsave">Save</button>
                                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                            <!-- Last modal add member -->
                          </div>
                        </div>
                        <p class="card-description"> You can update the members here!</p>
                        <!-- <button type="button" class="btn btn-info">Add Collection</button> -->
                        <div class="table-responsive" style="max-height: 300px;">
                          <table class="table">
                            <thead>
                              <tr>
                                <th>No.</th>
                                <th>Full Name</th>
                                <th>Address</th>
                                <th>Phone Number</th>
                                <th>E-mail</th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $id_m=1;?>
                              <?php foreach ($librarian_member as $row): ?>
                              <tr>
                                <td><?= $id_m;?></td>
                                <td><?= $row["member_name"];?></td>
                                <td><?= $row["member_address"];?></td>
                                <td><?= $row["member_phone_number"];?></td>
                                <td><?= $row["member_email"];?></td>
                                <td>
                                  <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modaleditmember<?=$id_m;?>">Edit</button>
                                  <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modaldeletmember<?=$id_m;?>">Delete</button>                
                                </td>
                              </tr>

                              <!-- Modal edit member -->
                              <div class="modal fade" id="modaleditmember<?=$id_m;?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="staticBackdropLabel">Edit member data</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                      <form method="POST" action="edit_lmember.php">
                                        <input type="hidden" name="id_member" value="<?=$row['id_member'];?>">
                                        <div class="mb-3">
                                          <label class="form-label">Full Name</label>
                                          <input type="text" class="form-control" name="mname" value="<?=$row['member_name'];?>" placeholder="Member full name"required>
                                        </div>
                                        <div class="mb-3">
                                          <label class="form-label">Address</label>
                                          <input type="text" class="form-control" name="maddress" value="<?=$row['member_address'];?>" placeholder="Member address">
                                        </div>
                                        <div class="mb-3">
                                          <label class="form-label">Phone Number</label>
                                          <input type="text" class="form-control" name="mpnumber" value="<?=$row['member_phone_number'];?>" placeholder="Member address">
                                        </div>
                                        <div class="mb-3">
                                          <label class="form-label">E-mail</label>
                                          <input type="text" class="form-control" name="memail" value="<?=$row['member_email'];?>" placeholder="Member E-mail">
                                    </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-success" name="bmedit">Save</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                                <!-- Last modal edit member -->
                              </div>

                              <!-- Modal delete member -->
                              <div class="modal fade" id="modaldeletmember<?=$id_m;?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="staticBackdropLabel">Delete member data</h5>
                                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                      <form method="POST" action="delete_lmember.php">
                                        <input type="hidden" name="id_member" value="<?=$row['id_member'];?>">
                                        <div class="mb-3">
                                            <label class="form-label">Are you sure delete the member data </label>
                                            <label class="form-label">named <b><?=$row['member_name'];?></b>???</label>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary bg-danger" name="bmdelete">Delete</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                                <!-- Last modal delete member -->
                              </div>
                              <?php $id_m++ ?>
                              <?php endforeach; ?> <!-- Closing 'foreach' -->
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  <!-- </div> -->
                </div>
              </div>

              <!-- BORROW AND RETURN -->
              <div class="content-wrapper">
                <div class="row">
                  <div class="col-lg-6 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <h4 class="card-title">Borrowing Collection History</h4>
                        <p class="card-description"> Here's the history, check this out!
                        </p>
                        <button type="button" class="btn btn-dark" style="position: absolute; top: 20px; right: 20px;" data-bs-toggle="modal" 
                                  data-bs-target="#modaladdborrow">
                          Add
                        </button>

                        <!-- Modal add borrow -->
                        <div class="modal fade" id="modaladdborrow" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="staticBackdropLabel">Add collection data</h5>
                                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                  <form method="POST" action="add_borrow.php">
                                    <div class="mb-3">
                                      <label class="form-label">Member Name</label>
                                      <select class="form-control" name="bname" required>
                                        <option value="">Select Member</option>
                                        <?php
                                            // Ambil data member dari database
                                            $sql_members = "SELECT id_member, member_name FROM member";
                                            $result_members = $conn->query($sql_members);
                                            while ($row = $result_members->fetch_assoc()) {
                                                echo "<option value='" . $row['id_member'] . "'>" . $row['member_name'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Collection Title</label>
                                        <select class="form-control" name="btitle" required>
                                            <option value="">Select Collection</option>
                                            <?php
                                            // Ambil data collection dari database
                                            $sql_collections = "SELECT id_collection, collection_title FROM collection";
                                            $result_collections = $conn->query($sql_collections);
                                            while ($row = $result_collections->fetch_assoc()) {
                                                echo "<option value='" . $row['id_collection'] . "'>" . $row['collection_title'] . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Borrow Date</label>
                                        <input type="date" class="form-control" name="bbodate" id="borrow_date" required onchange="calculateDueDate()">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Due Date</label>
                                        <input type="date" class="form-control" name="bdudate" id="due_date" readonly>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-success" name="bbsave">Save</button>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    </div>
                                </form>
                                </div>
                              </div>
                            </div>
                            <!-- Last modal add collection -->
                          </div>

                        <div class="table-responsive" style="max-height: 300px;">
                          <table class="table">
                            <thead>
                              <tr>
                                <th>Member Name</th>
                                <th>Collection Title</th>
                                <th>Borrow Date</th>
                                <th>Due Date</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php foreach ($borrowing_list as $row): ?>
                              <tr>
                                <td><?= $row["member_name"];?></td>
                                <td><?= $row["collection_title"];?></td>
                                <td><?= $row["borrow_date"];?></td>
                                <td><?= $row["due_date"];?></td>
                              </tr>
                              <?php endforeach; ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- -------- -->
                  <div class="col-lg-6 grid-margin stretch-card">
                    <div class="card">
                      <div class="card-body">
                        <h4 class="card-title">Returning Collection History</h4>
                        <p class="card-description"> Here's the history, check this out! 
                        </p>
                        <div class="table-responsive" style="max-height: 300px;">
                          <table class="table">
                            <thead>
                              <tr>
                                <th>Member Name</th>
                                <th>Collection Title</th>
                                <th>Return Date</th>
                                <th>Status</th>
                                <th></th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php foreach ($return_list as $row): ?>
                                <tr id="borrowing_<?=$row['id_borrowing_collection'];?>">
                                  <td><?= $row["member_name"]; ?></td>
                                  <td><?= $row["collection_title"]; ?></td>
                                  <td id="return_date_<?=$row['id_borrowing_collection'];?>"><?= isset($row["return_date"]) ? date('d M Y', strtotime($row["return_date"])) : 'N/A'; ?></td>
                                  <td id="status_<?=$row['id_borrowing_collection'];?>">
                                      <?php
                                      if ($row["status"] == "pending") {
                                          echo '<label class="badge badge-danger">Pending</label>';
                                      } else {
                                          echo '<label class="badge badge-success">Returned</label>';
                                      }
                                      ?>
                                  </td>
                                  <td>
                                      <?php if ($row["status"] == "pending"): ?>
                                          <button type="button" class="btn btn-success" onclick="confirmReturn(<?=$row['id_borrowing_collection'];?>)">
                                              <i class="mdi mdi-check-circle"></i>
                                          </button>
                                      <?php else: ?>
                                          <button class="btn btn-success" disabled>
                                              <i class="mdi mdi-close-circle"></i>
                                          </button>
                                      <?php endif; ?>
                                  </td>
                                </tr>
                              <?php endforeach; ?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>


            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
              <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2023. Premium <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap admin template</a> from BootstrapDash. All rights reserved.</span>
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="ti-heart text-danger ms-1"></i></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/vendors/chart.js/chart.umd.js"></script>
    <script src="assets/vendors/datatables.net/jquery.dataTables.js"></script>
    <!-- <script src="assets/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script> -->
    <script src="assets/vendors/datatables.net-bs5/dataTables.bootstrap5.js"></script>
    <script src="assets/js/dataTables.select.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/template.js"></script>
    <script src="assets/js/settings.js"></script>
    <script src="assets/js/todolist.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="assets/js/jquery.cookie.js" type="text/javascript"></script>
    <script src="assets/js/dashboard.js"></script>
    <!-- <script src="assets/js/Chart.roundedBarCharts.js"></script> -->
    <!-- End custom js for this page-->
  </body>

  <script>
  // Function to calculate Due Date (7 days after Borrow Date)
  function calculateDueDate() {
    var borrowDate = document.getElementById('borrow_date').value;
    if (borrowDate) {
      var dueDate = new Date(borrowDate);
      dueDate.setDate(dueDate.getDate() + 7); // Add 7 days
      var year = dueDate.getFullYear();
      var month = (dueDate.getMonth() + 1).toString().padStart(2, '0'); // Add leading zero if needed
      var day = dueDate.getDate().toString().padStart(2, '0'); // Add leading zero if needed
      document.getElementById('due_date').value = year + '-' + month + '-' + day; // Set Due Date
    }
  }

  function confirmReturn(borrowingId) {
    // Konfirmasi pengembalian
    if (confirm("Are you sure you want to mark this as returned?")) {
        // Kirim permintaan untuk mengupdate data
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "update_return.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                // Tampilkan notifikasi sukses
                alert('Return date updated successfully!');
                // Perbarui status dan tanggal pengembalian di halaman
                document.getElementById("return_date_" + borrowingId).innerText = new Date().toLocaleDateString();
                document.getElementById("status_" + borrowingId).innerHTML = '<label class="badge badge-success">Returned</label>';
            }
        };
        // Kirim ID borrowing collection untuk update
        xhr.send("borrowing_id=" + borrowingId);
    }
  }
</script>

</html>