<?php
include "connection.php";

if (isset($_POST['bbsave'])) {
    // Mengambil data dari form
    $id_member = $_POST['bname']; // Member ID dari dropdown
    $id_collection = $_POST['btitle']; // Collection ID dari dropdown
    $borrow_date = $_POST['bbodate'];

    // Menghitung due date (7 hari setelah borrow date)
    $due_date = date('Y-m-d', strtotime($borrow_date . ' +7 days'));

    // Menyimpan data ke tabel borrowing_collection
    $sql_borrowing = "INSERT INTO borrowing_collection (id_member, id_collection, borrow_date, due_date)
                      VALUES ('$id_member', '$id_collection', '$borrow_date', '$due_date')";

    if ($conn->query($sql_borrowing) === TRUE) {
        // Mendapatkan ID terakhir dari borrowing_collection
        $id_borrowing_collection = $conn->insert_id;

        // Menyimpan data ke tabel return_collection
        $sql_return = "INSERT INTO return_collection (id_borrowing_collection, return_date, status)
                       VALUES ('$id_borrowing_collection', NULL, 'pending')";

        if ($conn->query($sql_return) === TRUE) {
            // Mengurangi stok pada tabel collection
            $sql_update_stock = "UPDATE collection 
                                 SET collection_stock = collection_stock - 1 
                                 WHERE id_collection = '$id_collection'";

            if ($conn->query($sql_update_stock) === TRUE) {
                echo "
                <script>
                    alert('Successfully saved borrowing data and updated stock!');
                    document.location.href = 'index.php';
                </script>
                ";
            } else {
                echo "Error updating stock: " . $conn->error;
            }
        } else {
            echo "Error saving return data: " . $conn->error;
        }
    } else {
        echo "Error saving borrowing data: " . $conn->error;
    }
}
?>
