<?php
include "connection.php";

if (isset($_POST['bedit'])) {
    $id_collection = $_POST['id_collection'];
    $title = $_POST['ctitle'];
    $author = $_POST['cauthor'];
    $publisher = $_POST['cpublisher'];
    $year = $_POST['cyear'];
    $category_id = $_POST['ccategory']; 
    $stock = $_POST['cstock'];

    $sql_check_category = "SELECT id_category FROM category WHERE id_category = '$category_id'";
    $result_check_category = $conn->query($sql_check_category);

    if ($result_check_category->num_rows > 0) {
        $sql_update = "UPDATE collection SET 
                            collection_title = '$title',
                            collection_author = '$author',
                            collection_publisher = '$publisher',
                            collection_year = '$year',
                            id_category = '$category_id',
                            collection_stock = '$stock'
                        WHERE id_collection = '$id_collection'";

        if ($conn->query($sql_update) === TRUE) {
            echo "
            <script>
                alert('Successfully updated the collection data!');
                document.location.href = 'index.php';
            </script>
            ";
        } else {
            echo "
            <script>
                alert('Failed to update collection data! Error: " . $conn->error . "');
                document.location.href = 'index.php';
            </script>
            ";
        }
    } else {
        echo "
        <script>
            alert('Invalid category selected!');
            document.location.href = 'index.php';
        </script>
        ";
    }
}
?>
