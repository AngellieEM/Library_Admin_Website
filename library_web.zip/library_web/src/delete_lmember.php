<?php
include "connection.php";

if (isset($_POST['bmdelete'])) {
    $id_member = $_POST['id_member'];

    $member_delete = "DELETE FROM member WHERE id_member = '$id_member'";

    if ($conn->query($member_delete) === TRUE) {
        echo "
        <script>
            alert('Successfully deleted the collection data!');
            document.location.href = 'index.php';
        </script>
        ";
    } else {
        echo "
        <script>
            alert('Failed to delete collection data! Error: " . $conn->error . "');
            document.location.href = 'index.php';
        </script>
        ";
    }
}
?>
