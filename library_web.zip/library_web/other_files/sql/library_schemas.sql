USE db_library;

-- Tabel Admin
CREATE TABLE admin (
    id_admin INT AUTO_INCREMENT PRIMARY KEY,
    admin_username VARCHAR(50) NOT NULL,
    admin_password VARCHAR(255) NOT NULL
);

-- Tabel Category
CREATE TABLE category (
    id_category INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL
);

-- Tabel Collection
CREATE TABLE collection (
    id_collection INT AUTO_INCREMENT PRIMARY KEY,
    collection_title VARCHAR(255) NOT NULL,
    collection_author VARCHAR(100),
    collection_publisher VARCHAR(100),
    collection_year INT,
    id_category INT NOT NULL,
    collection_stock INT NOT NULL,
    FOREIGN KEY (id_category) REFERENCES Category(id_category)
);

-- Tabel Member
CREATE TABLE member (
    id_member INT AUTO_INCREMENT PRIMARY KEY,
    member_name VARCHAR(100) NOT NULL,
    member_address VARCHAR(255),
    member_phone_number VARCHAR(15),
    member_email VARCHAR(100)
);

-- Tabel Borrowing
CREATE TABLE borrowing_collection (
    id_borrowing_collection INT AUTO_INCREMENT PRIMARY KEY,
    id_member INT NOT NULL,
    id_collection INT NOT NULL,
    borrow_date DATE NOT NULL,
    due_date DATE NOT NULL,
    FOREIGN KEY (id_member) REFERENCES Member(id_member),
    FOREIGN KEY (id_collection) REFERENCES Collection(id_collection)
);

-- Tabel Return
CREATE TABLE return_collection (
    id_return_collection INT AUTO_INCREMENT PRIMARY KEY,
    id_borrowing_collection INT NOT NULL,
    return_date DATE ,
    status TEXT,
    FOREIGN KEY (id_borrowing_collection) REFERENCES Borrowing_collection(id_borrowing_collection)
);